"""SShell - Persistent shell sessions that survive SSH disconnections."""

__version__ = '1.6.1'

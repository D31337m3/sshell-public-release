"""Client components for CLI interaction."""

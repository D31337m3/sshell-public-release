"""Common data structures and utilities."""

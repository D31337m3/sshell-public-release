"""Daemon components for session management."""
